package com.example.jastip;

import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;

import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MakananActivity extends AppCompatActivity {
    private TextView tvseafod,tvbakso,tvbaksoikan,tvotak,tvtahu,tvsop;
    private Button btnpesanseafod,btnpesanbakso,btnpesanbaksoikan,btnpesanotak,btnpesantahu,btnpesansop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_makanan);

        tvseafod = findViewById(R.id.tvseafod);
        tvbakso = findViewById(R.id.tvbakso);
        tvbaksoikan = findViewById(R.id.tvbaksoikan);
        tvotak = findViewById(R.id.tvotak);
        tvtahu = findViewById(R.id.tvtahu);
        tvsop = findViewById(R.id.tvsop);

        btnpesanseafod = findViewById(R.id.btnpesanseafod);
        btnpesanbakso = findViewById(R.id.btnpesanbakso);
        btnpesanbaksoikan = findViewById(R.id.btnpesanbaksoikan);
        btnpesanotak = findViewById(R.id.btnpesanotak);
        btnpesantahu = findViewById(R.id.btnpesantahu);
        btnpesansop = findViewById(R.id.btnpesansop);

        btnpesanseafod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvseafod.getText().toString().replace("Seadfod Merakyat : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesanbakso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvbakso.getText().toString().replace("Bakso Podo Moro : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesanbaksoikan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvbaksoikan.getText().toString().replace("Kedai Bakso Ikan Kang Dai : Pesan Apa", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesanotak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvotak.getText().toString().replace("Otak - Otak Aa Yayon : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesantahu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvtahu.getText().toString().replace(" Tahu Kaget Kang Bahar : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesansop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvsop.getText().toString().replace("Dapur Sunda : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
    }
    private void sendOrderToWhatsApp(String orderName) {
        String phoneNumber = "+6283187255204"; // Ganti dengan nomor tujuan
        String message ="silahkan jastip di   " + orderName;
        String url = "https://api.whatsapp.com/send?phone=" + phoneNumber + "&text=" + Uri.encode(message);

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}