package com.example.jastip;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;


public class MinumanActivity extends AppCompatActivity {

    private TextView tvkelde,tvkelda,tvtehsa,tvcapci,tvkeljum,tvteler;
    private Button btnpesankelapa,btnpesankelpadai,btnpesantehsolo,btnpesancapucino,btnpesankelpawajum,btnpesanteler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minuman);

        tvkelde = findViewById(R.id.tvkelde);
        tvkelda = findViewById(R.id.tvkelda);
        tvtehsa = findViewById(R.id.tvtehsa);
        tvkeljum = findViewById(R.id.tvkeljum);
        tvcapci = findViewById(R.id.tvcapci);
        tvteler = findViewById(R.id.tvteler);
        btnpesankelapa = findViewById(R.id.btnpesankelapa);
        btnpesankelpadai = findViewById(R.id.btnpesankelpadai);
        btnpesantehsolo = findViewById(R.id.btnpesantehsolo);
        btnpesancapucino = findViewById(R.id.btnpesancapucino);
        btnpesankelpawajum = findViewById(R.id.btnpesankelpawajum);
        btnpesanteler = findViewById(R.id.btnpesanteler);

        btnpesankelapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvkelde.getText().toString().replace("Es Kelapa Ceu Dewi : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesankelpadai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvkelda.getText().toString().replace("Kedai Kelapa Kang Dai : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesantehsolo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvtehsa.getText().toString().replace("Es Teh Solo Pak Saman : Pesan Apa", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesancapucino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvcapci.getText().toString().replace("Es Cappucino Cincau Pak Iren : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesankelpawajum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvkeljum.getText().toString().replace("Es Kelapa Pak Wajum : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });
        btnpesanteler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String orderName = tvteler.getText().toString().replace("Kedai es teler Kang Dai : Pesan Apa ", "");

                if (!orderName.isEmpty()) {
                    sendOrderToWhatsApp(orderName);
                }
            }
        });


    }
    private void sendOrderToWhatsApp(String orderName) {
        String phoneNumber = "+6283187255204"; // Ganti dengan nomor tujuan
        String message ="silahkan jastip di   " + orderName;
        String url = "https://api.whatsapp.com/send?phone=" + phoneNumber + "&text=" + Uri.encode(message);

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}